THETAMASHAGUY PORTFOLIO — QUICK START

Preview locally:
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, or Firefox.

Publish online (simple option: Netlify Drop):
1. Visit https://app.netlify.com/drop
2. Sign in or create a free account if prompted.
3. Drag the extracted thetamashaguy_portfolio folder onto the page (or upload the folder contents if prompted).
4. Netlify will provide a public website URL.

Before sharing publicly, update these placeholders in index.html:
- Replace the generic LinkedIn URL with your actual LinkedIn profile.
- Add your professional email if you want email enquiries.
- Add links to your real writing samples and replace the sample-to-be-added labels.

This is a responsive, static website. It does not require a build step or a backend.
